

<!DOCTYPE html>
<html lang="en">
   <head>
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>IntroVerse</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- bootstrap css -->
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <!-- style css -->
      <link rel="stylesheet" href="css/style.css">
      <!-- Responsive-->
      <link rel="stylesheet" href="css/responsive.css">
      <!-- fevicon -->
      <link rel="icon" href="images/fevicon.png" type="image/gif" />
      <!-- Scrollbar Custom CSS -->
      <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
      <!-- Tweaks for older IEs-->
      <link rel="stylesheet" href="css/signup.css">
      <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
      <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
   </head>
   <!-- body -->
   <body class="main-layout">
      <!-- loader  -->
      <div class="loader_bg">
         <div class="loader"><img src="images/loading.gif" alt="#" /></div>
      </div>
      <!-- end loader -->
      <!-- header -->
      <header>
         <!-- header inner -->
         <div class="header">
            <div class="container">
               <div class="row">
                  <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col logo_section">
                     <div class="full">
                        <div class="center-desk">
                           <div class="logo">
                              <a href="index.php"><p>IntroVerse</p></a>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-9 col-lg-9 col-md-9 col-sm-9">
                     <nav class="navigation navbar navbar-expand-md navbar-dark ">
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample04" aria-controls="navbarsExample04" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarsExample04">
                           <ul class="navbar-nav mr-auto">
                              <li class="nav-item active">
                                 <a class="nav-link" href="index.php">Home</a>
                              </li>
                              <li class="nav-item">
                                 <a class="nav-link" href="#"> About  </a>
                              </li>
                              <li class="nav-item">
                                 <a class="nav-link" href="#service"> Service</a>
                              </li>
                              <li class="nav-item">
                                 <a class="nav-link" href="#contact">Contact</a>
                              </li>
                              <li class="nav-item">
                                 <a class="nav-link" href="login.php">Log In</a>
                              </li>
                           </ul>
                        </div>
                     </nav>
                  </div>
               </div>
            </div>
         </div>
      </header>
      <!-- end header inner -->
      <!-- end header -->
      <!-- banner -->
      <section class="banner_main">
         <div id="form">
         <form action="index.php" method="post">
            <table id="tbl">
               <tr>
                  <td><p>First Name</p></td>
                  <td><p>:</p></td>
                  <td><input type="text" name="fname" placeholder="Enter first name..."></td>
               </tr>
               <tr>
                  <td><p>Last Name</p></td>
                  <td><p>:</p></td>
                  <td><input type="text" name="lname" placeholder="Enter last name..."></td>
               </tr>
               <tr>
                  <td><p>E-mail.I'd</p></td>
                  <td><p>:</p></td>
                  <td><input type="email" name="email" placeholder="Enter your email address..."></td>
               </tr>
               <tr>
                  <td><p>Contact Number</p></td>
                  <td><p>:</p></td>
                  <td><input type="text" name="cntNumber" placeholder="Enter phone number..."></td>
               </tr>
               <tr>
                  <td><p>Gender</p></td>
                  <td><p>:</p></td>
                  <td>
                     <input type="radio" name="gender" checked value="Male">Male&nbsp&nbsp
                     <input type="radio" name="gender" value="Female">Female&nbsp&nbsp
                     <input type="radio" name="gender" value="Others">Others&nbsp&nbsp 
                     <input type="radio" name="gender" value="null">Prefered Not To Choose
                  </td>
               </tr>
               <tr>
                  <td><p>Date Of Birth</p></td>
                  <td><p>:</p></td>
                  <td><input type="date" name="dob" placeholder="Enter your birthdate..."></td>
               </tr>
               <tr>
                  <td><p>Hobby</p></td>
                  <td><p>:</p></td>
                  <td>
                     <input type="checkbox" name="hobby">Music&nbsp
                     <input type="checkbox" name="hobby">Singing&nbsp
                     <input type="checkbox" name="hobby">Dancing&nbsp
                     <input type="checkbox" name="hobby">Reading&nbsp
                     <input type="checkbox" name="hobby">Travelling&nbsp
                  </td>
               </tr>
               <tr>
                  <td><button type="reset" name="reset" id="reset" class="btn btn-outline-danger">Reset</td>
                  <td></td>
                  <td><button type="submit" name="submit" id="submit" class="btn btn-outline-success">Submit</td>
               </tr>
            </table>
         <?php
            if(array_key_exists("submit",$_POST))
            {
               if(empty($_POST["fname"]) || empty($_POST["lname"]) || empty($_POST["dob"]) || empty($_POST["hobby"]) || empty($_POST["cntNumber"]))
               {
                  echo "<div class='alert alert-danger' role='alert'>Please Fill All The Mendatory Details.</div>";
               }
               else
               {
                  $fname = $_POST["fname"];
                  $lname = $_POST["lname"];
                  $gender = $_POST["gender"];
                  if($gender == "Male")
                     echo '<div class="alert alert-success" role="alert">Welcome Mr. '.$fname.' '.$lname.'</div>';
                  else if($gender == "Female")
                     echo '<div class="alert alert-success" role="alert">Welcome Mrs./Ms. '.$fname.' '.$lname.'</div>';
                  else
                     echo '<div class="alert alert-success" role="alert">Welcome '.$fname.' '.$lname.'</div>';
               }
            }
         ?>
         </form>
         </div>
      </section>
      <!-- end contact -->
      <!--  footer -->
      <footer>
         <div class="footer">
            <div class="container">
               <div class="row">
                  <div class="col-md-10 offset-md-1">
                     <div class="cont">
                        
                     </div>
                  </div>
               </div>
            </div>
            <div class="copyright">
               <div class="container">
                  <div class="row">
                     <div class="col-md-12">
                        <p>© 2022 All Rights Reserved. <a href="https://html.design/"></a></p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
    
      </footer>
      <!-- end footer -->
      <!-- Javascript files-->
      <script src="js/jquery.min.js"></script>
      <script src="js/popper.min.js"></script>
      <script src="js/bootstrap.bundle.min.js"></script>
      <script src="js/jquery-3.0.0.min.js"></script>
      <script src="js/plugin.js"></script>
      <!-- sidebar -->
      <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
      <script src="js/custom.js"></script>
      <script src="https:cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>
   </body>
</html>

