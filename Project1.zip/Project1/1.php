<html>
    <head>
        <title>First Form</title>
    </head>
    <body>
        <form method="post">
            <table>
                <tr>
                    <td><p>First Name</p></td>
                    <td><p>:</p></td>
                    <td><input type="text" placeholder="Enter Your First Name....." name="fname"></td>
                </tr>
                <tr>
                    <td><p>Last Name</p></td>
                    <td><p>:</p></td>
                    <td><input type="text" placeholder="Enter Your Last Name....." name="lname"></td>
                </tr>
                <tr>
                    <td><p>Contact Number</p></td>
                    <td><p>:</p></td>
                    <td><input type="text" placeholder="Enter Your Contact Number....." name="cntnumber"></td>
                </tr>
                <tr>
                    <td><p>Email I'd</p></td>
                    <td><p>:</p></td>
                    <td><input type="email" placeholder="Enter Your Email....." name="email"></td>
                </tr>
                <tr>
                    <td><p>Gender</p></td>
                    <td><p>:</p></td>
                    <td>
                        <input type="radio" name="gender">Male
                        <input type="radio" name="gender">Female
                        <input type="radio" name="gender">Others
                    </td>
                </tr>
                <tr>
                    <td><p>Date Of Birth</p></td>
                    <td><p>:</p></td>
                    <td><input type="date" name="dob" placeholder="Enter Your Date Of Birth....."></td>
                </tr>
                <tr>
                    <td><p>Hobby</p></td>
                    <td><p>:</p></td>
                    <td>
                        <input type="checkbox" name="hobby">Reading
                        <input type="checkbox" name="hobby">Swimming
                        <input type="checkbox" name="hobby">Singing
                        <input type="checkbox" name="hobby">Traveling
                    </td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td>
                        <button type="submit">Submit</button>
                        <button type="reset">Reset</button>
                    </td>
                </tr>
            </table>
        </form>
        <?php
        echo "Hello World!!!";
        ?>
    </body>
</html>
